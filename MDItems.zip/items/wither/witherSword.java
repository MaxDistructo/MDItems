package com.github.MaxDistructo.MDItems.items.wither;

import net.minecraft.item.ItemSword;

public class witherSword extends ItemSword{

    public witherSword(String unlocalizedName, ToolMaterial material) {
        super(material);
        this.setUnlocalizedName(unlocalizedName);
    }
}
